@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Страница Alex</h1>
        <p>Доступно только администраторам</p>
    </div>
@endsection
