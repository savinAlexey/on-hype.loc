@extends('layouts.app')

@section('content')
<main class="container flex-grow-1 d-flex flex-column justify-content-center">
    <p>Главная страница</p>
</main>
@endsection


