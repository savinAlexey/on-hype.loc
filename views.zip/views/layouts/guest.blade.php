<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['resources/sass/app.scss', 'resources/js/app.js'])
    </head>
    <body class="font-sans text-body bg-light">
    <div class="min-vh-100 d-flex flex-column justify-content-center align-items-center pt-5 pb-5">
        <div class="mb-4">
            <a href="/" class="text-decoration-none">
                <x-application-logo class="d-block" style="width: 5rem; height: 5rem; color: #6c757d;" />
            </a>
        </div>

        <div class="w-100 p-4 bg-white shadow-sm" style="max-width: 28rem; border-radius: 0.5rem;">
            {{ $slot }}
        </div>
    </div>
    </body>
</html>
